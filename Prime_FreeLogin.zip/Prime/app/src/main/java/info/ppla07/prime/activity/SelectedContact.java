package info.ppla07.prime.activity;

import android.app.Activity;
import android.os.Bundle;

import info.ppla07.prime.R;

public class SelectedContact extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selected_contact);
    }
}
